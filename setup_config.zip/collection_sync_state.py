from __future__ import annotations

import sqlite3
from typing import Any, Dict, Optional


SYNC_STATE_SCHEMA = """
CREATE TABLE IF NOT EXISTS collection_sync_state (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    mode TEXT NOT NULL,
    bootstrap_completed INTEGER NOT NULL DEFAULT 0,
    last_sync_at TEXT,
    last_event_time_seen TEXT,
    oldest_event_time_seen TEXT,
    target_start_time TEXT,
    coverage_complete INTEGER NOT NULL DEFAULT 0,
    stop_reason TEXT,
    pages_fetched_last_run INTEGER NOT NULL DEFAULT 0
)
"""


def ensure_collection_sync_schema(conn: sqlite3.Connection) -> None:
    conn.execute(SYNC_STATE_SCHEMA)
    conn.commit()


def read_collection_sync_state(conn: sqlite3.Connection) -> Optional[Dict[str, Any]]:
    ensure_collection_sync_schema(conn)
    row = conn.execute(
        """
        SELECT
            mode,
            bootstrap_completed,
            last_sync_at,
            last_event_time_seen,
            oldest_event_time_seen,
            target_start_time,
            coverage_complete,
            stop_reason,
            pages_fetched_last_run
        FROM collection_sync_state
        WHERE id = 1
        """
    ).fetchone()
    if row is None:
        return None
    return {
        "mode": row[0],
        "bootstrap_completed": bool(row[1]),
        "last_sync_at": row[2],
        "last_event_time_seen": row[3],
        "oldest_event_time_seen": row[4],
        "target_start_time": row[5],
        "coverage_complete": bool(row[6]),
        "stop_reason": row[7],
        "pages_fetched_last_run": int(row[8] or 0),
    }


def write_collection_sync_state(
    conn: sqlite3.Connection,
    *,
    mode: str,
    bootstrap_completed: bool,
    last_sync_at: Optional[str],
    last_event_time_seen: Optional[str],
    oldest_event_time_seen: Optional[str],
    target_start_time: Optional[str],
    coverage_complete: bool,
    stop_reason: Optional[str],
    pages_fetched_last_run: int,
) -> None:
    ensure_collection_sync_schema(conn)
    conn.execute(
        """
        INSERT INTO collection_sync_state (
            id,
            mode,
            bootstrap_completed,
            last_sync_at,
            last_event_time_seen,
            oldest_event_time_seen,
            target_start_time,
            coverage_complete,
            stop_reason,
            pages_fetched_last_run
        )
        VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            mode = excluded.mode,
            bootstrap_completed = excluded.bootstrap_completed,
            last_sync_at = excluded.last_sync_at,
            last_event_time_seen = excluded.last_event_time_seen,
            oldest_event_time_seen = excluded.oldest_event_time_seen,
            target_start_time = excluded.target_start_time,
            coverage_complete = excluded.coverage_complete,
            stop_reason = excluded.stop_reason,
            pages_fetched_last_run = excluded.pages_fetched_last_run
        """,
        (
            mode,
            1 if bootstrap_completed else 0,
            last_sync_at,
            last_event_time_seen,
            oldest_event_time_seen,
            target_start_time,
            1 if coverage_complete else 0,
            stop_reason,
            int(pages_fetched_last_run or 0),
        ),
    )
    conn.commit()


def reset_collection_sync_state(conn: sqlite3.Connection) -> None:
    ensure_collection_sync_schema(conn)
    conn.execute("DELETE FROM collection_sync_state")
    conn.commit()


def count_collection_events(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT COUNT(*) FROM content_engagement_events").fetchone()
    return int(row[0] or 0) if row else 0
